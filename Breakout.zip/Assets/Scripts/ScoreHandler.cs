using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreHandler : MonoBehaviour
{
    public static int score = 0;
    public static ScoreHandler currentHandler = null;
    Text text;

    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<Text>();
        currentHandler = this;
    }

    private void FormatScore()
    {
        text.text = "SCORE: " + score;
    }

    public static void AddScore(int increment)
    {
        score += increment;
        if (currentHandler != null)
            currentHandler.FormatScore();
    }
}
