using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class BlockBehaviour : MonoBehaviour
{
    public int hitsRequired = 1;
    private UnityEvent callWhenBroken;
    private void OnCollisionEnter2D(Collision2D other)
    {
        hitsRequired--;
        if (hitsRequired < 1)
        {
            UpdateColor();
            callWhenBroken?.Invoke();
            ScoreHandler.AddScore(1);
            Destroy(gameObject);

        }
    }
    public void RegisterEvent(UnityEvent e)
    {
        callWhenBroken = e;
    }
    public void UpdateColor()
    {
        float lightness = 1f / hitsRequired;
        GetComponent<SpriteRenderer>().color = new Color(lightness, lightness, lightness);
    }
}
