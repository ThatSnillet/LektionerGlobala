    using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FailZone : MonoBehaviour
{
    public GameObject gameOverText;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.name == "Ball")
        {
            other.gameObject.SetActive(false);
            gameOverText.SetActive(true);
        }
    }
}
