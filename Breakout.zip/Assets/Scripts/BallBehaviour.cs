using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallBehaviour : MonoBehaviour
{
    public float startSpeed = 7f;
    public static BallBehaviour mainBall = null;
    private Rigidbody2D body;
    private Vector3 startPos;
    // Start is called before the first frame update
    void Start()
    {
        body = GetComponent<Rigidbody2D>();
        startPos = transform.position;
        body.velocity = Vector2.up * startSpeed;
        mainBall = this;
    }
    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            float hitFactor = ((transform.position.x - other.transform.position.x) / other.collider.bounds.size.x);

            hitFactor += other.gameObject.GetComponent<Rigidbody2D>().velocity.x * 0.1f;

            Vector2 newDirection = new Vector2(hitFactor,1).normalized;

            GiveUpVelocity();
        }
    }

    public void ReturnBall()
    {
        transform.position = startPos;
        GiveUpVelocity();
    }

    public static void ReturnMainBall()
    {
        if (mainBall != null)
            mainBall.ReturnBall();
    }
    public static float GetMainBallX()
    {
        if (mainBall != null)
            return mainBall.transform.position.x;
        else
            return 0;
    }

    private void GiveUpVelocity()
    {
        float angle = Random.Range(Mathf.PI*0.4f, Mathf.PI * 0.6f);
        body.velocity = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * startSpeed;
    }
}
