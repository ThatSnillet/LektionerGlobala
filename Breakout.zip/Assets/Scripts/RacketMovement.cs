using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RacketMovement : MonoBehaviour
{
    public float moveSpeed = 5f;

    private Rigidbody2D body;
    private void Start()
    {
        body = GetComponent<Rigidbody2D>();
    }
    private void FixedUpdate()
    {
        float movement = Input.GetAxisRaw("Horizontal");
        //float movement = Mathf.Clamp(BallBehaviour.GetMainBallX() - transform.position.x + (0.5f * Mathf.Sign(transform.position.x)), -moveSpeed, moveSpeed);
        body.velocity = Vector2.right * movement * moveSpeed;
    }
}
