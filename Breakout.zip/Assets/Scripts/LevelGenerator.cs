using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class LevelGenerator : MonoBehaviour
{
    public GameObject block;

    private Vector2 blockSize = new Vector2(1f, 0.4f);
    private float levelWidth = 9f;
    private float blockSpacing = 0.1f;
    private GameObject currentLevel;
    private int levelNum = 0;

    public UnityEvent levelWin = new UnityEvent();

    private void Start()
    {
        levelWin.AddListener(OnWin);
        GenerateLevel();
    }

    private void GenerateLevel()
    {
        levelNum++;
        currentLevel = new GameObject("Level");

        int numBlocks = 4 + Mathf.Min(levelNum, 16);

        GameObject temp;
        float xOffset = blockSize.x * 0.5f + (Mathf.Min(numBlocks * blockSize.x, levelWidth) * -0.5f);
        Vector3 tempLoc = new Vector3(xOffset,3,0);

        for (int i = 0; i < numBlocks; i++)
        {
            temp = Instantiate(block, tempLoc, Quaternion.identity);
            tempLoc.x  = tempLoc.x + blockSize.x + blockSpacing;
            if ((tempLoc.x - xOffset) > levelWidth)
            {
                tempLoc.x = xOffset;
                tempLoc.y = tempLoc.y + blockSize.y + blockSpacing;
            }
            temp.transform.SetParent(currentLevel.transform);

        }

        currentLevel.AddComponent<Level>().RegisterFinishedEvent(levelWin);
    }

    private void OnWin()
    {
        Destroy(currentLevel);
        GenerateLevel();
    }
}
