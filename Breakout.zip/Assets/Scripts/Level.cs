using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Level : MonoBehaviour
{
    public GameObject activate = null;
    private UnityEvent blockBroken = new UnityEvent();
    private int requiredBlocks;
    private UnityEvent callWhenFinished;
    private void Start()
    {
        var blocks = GetComponentsInChildren<BlockBehaviour>();

        foreach (var item in blocks)
        {
            item.RegisterEvent(blockBroken);
        }

        requiredBlocks = blocks.Length;

        blockBroken.AddListener(whenBlockBroken);
    }

    private void whenBlockBroken()
    {
        requiredBlocks--;
        if (requiredBlocks < 1)
        {
            gameObject.SetActive(false);
            BallBehaviour.ReturnMainBall();
            callWhenFinished?.Invoke();
            if (activate != null)
                activate.SetActive(true);
        }
    }

    public void RegisterFinishedEvent(UnityEvent e)
    {
        callWhenFinished = e;
    }
}
